from discord_webhook import DiscordWebhook, DiscordEmbed

def webhooks(webhooks, title, description, color):
    webhook = DiscordWebhook(url=f'{webhooks}')
    embed = DiscordEmbed(title=f'{title}', description=f'{description}', color=f'{color}', url='https://discord.gg/gxj8vR3nYQ', icon_url = 'https://media.discordapp.net/attachments/1013830586516906074/1013847215443300512/unknown.png')
    embed.set_thumbnail(url="https://media.discordapp.net/attachments/1013830586516906074/1013847215443300512/unknown.png")
    embed.set_author(
        name="VENEX",
        url="https://media.discordapp.net/attachments/1013830586516906074/1013847215443300512/unknown.png",
        icon_url="https://media.discordapp.net/attachments/1013830586516906074/1013847215443300512/unknown.png",
    )
    webhook.add_embed(embed)
    response = webhook.execute()