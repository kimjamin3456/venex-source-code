import pymysql
import requests as rq
import asyncio
def bank(tossid, name, amount):
    while True:
        cash_req = rq.post(
            f"https://api-gateway.toss.im:11099/api-public/v3/cashtag/transfer-feed/received/list?inputWord={tossid}",
            headers={"X-Toss-Method": "GET"}
        )
        cash_data = cash_req.json()['success']['data']
        censored_name_list = list(name)
        censored_name_list[1] = '*'
        censored_name = "".join(censored_name_list)
        for data in cash_data:
            if data['senderDisplayName'] == censored_name:
                if data['amount'] == amount:
                    return True
                else:
                    asyncio.sleep(1)
            else:
                asyncio.sleep(1)
        else:
            asyncio.sleep(1)

