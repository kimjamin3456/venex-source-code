from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver import ActionChains
import selenium
import app
import time

ID = "[your_id]"
PW = "[your_pw]"

def click_virtual_btn(driver, target):
    func_g = driver.find_element_by_xpath("//img[@alt='{}']".format(target))
    func_g = func_g.find_element_by_xpath("./../..")
    func_g.click()

def charge_pin(pin):
    try:
        driver = webdriver.Chrome("./chromedriver.exe")#, options=chrome_options)

        # 로그인하기
        driver.get("https://m.cultureland.co.kr/mmb/loginMain.do")

        WebDriverWait(driver, 200).until(
                EC.element_to_be_clickable((By.ID, 'btnLogin'))
            )

        driver.find_element_by_name("userId").send_keys(ID)

        driver.find_element_by_name("passwd").click()

        for i in PW:
            click_virtual_btn(driver, i)

        driver.find_element_by_id("mtk_done").click()
        driver.find_element_by_id("btnLogin").click()

        # 핀번호 충전하기
        driver.get("https://m.cultureland.co.kr/csh/cshGiftCard.do")

        WebDriverWait(driver, 200).until(
                EC.element_to_be_clickable((By.ID, 'btnCshFrom'))
            )
        driver.find_element_by_id("txtScr11").send_keys(pin[0:4])
        driver.find_element_by_id("txtScr12").send_keys(pin[4:8])
        driver.find_element_by_id("txtScr13").send_keys(pin[8:12])
        for i in range(12, len(pin)):
            click_virtual_btn(driver, pin[i])
            time.sleep(0.1)
            
        time.sleep(1)
        driver.find_element_by_id("btnCshFrom").click()

        # 결과 확인하기
        WebDriverWait(driver, 200).until(
                EC.element_to_be_clickable((By.ID, 'inSafeSub'))
            )

        result = driver.find_element_by_xpath("//*[@id='wrap']/div[3]/section/dl/dd").get_attribute("innerHTML")
        result = result[:-1]
        driver.quit()
        return result
    except:
        return "0"
