import sqlite3
from utils import webhook
import time


def send_webhook(name):
    webhook.webhooks('https://discord.com/api/webhooks/1013858638382759936/TqTtv95zJu28eebb6bHGUiFY95LamesGH5-OFZxsThxwR0HtN5i3F_ZrmnKxA_RmEm6Y', 'Venex WEB Vend', f'{name} 로그인 \n IP : None', '03b2f8')
