function clikonselectbar() {
    document.querySelector('.select_box').style.display = 'block';
}

function cliknoneselectbar() {
    document.querySelector('.select_box').style.display = 'none';
}

function g(){
    setTimeout(o, 1);
}
function o(){
    window.open('bank.html');
}

function checkss() {
    const result = prompt('문상, 게좌 중 택일')
    if (result == '문상') {
        window.open('http://localhost/api/culturland', 'Bank wallet','width=1024, height=1080')
    } else if(result=='계좌') {
        window.open('http://localhost/api/bank', 'Bank wallet','width=1024, height=1080')
    } else {
        alert("선택 한거 재확인 부탁드립니다.")
    }
}