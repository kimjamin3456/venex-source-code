import os
from types import GetSetDescriptorType
from xml.etree.ElementTree import QName
from utils import culturland
from utils import webhook
from utils import bank
import time
from flask import Flask, render_template, request
from flask import session, redirect, url_for, abort, jsonify
import pymysql
app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'



def logins(id, pw):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='protector', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute("SELECT * FROM account WHERE username='"+str(id)+"';")
    rows = cur.fetchone()
    cur.execute(f"UPDATE account SET connect='{time.strftime('%Y/%m/%d %H:%M')}' WHERE username='{str(id)}';")
    con.commit()
    con.close()
    if rows != None:
        if rows["password"] == pw:
            return True 
        else:
            return False 
    else:
        return False

cwdir =  os.path.dirname(__file__) + "/"

def get_name():
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='protector', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    cur.execute(f"SELECT * FROM venex")
    return cur.fetchall()


def getsite_id(siteid):
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='protector', charset='utf8')
    cur = con.cursor(pymysql.cursors.DictCursor)
    rows = cur.execute(f"SELECT * FROM siteid WHERE site_id = '{siteid}'")
    print(rows)
    if rows == 1:
        return True
    elif rows == 0:
        return False

def set_amount(amounts, name):
    print(amounts, name)
    con = pymysql.connect(user='root', passwd='', host='127.0.0.1', db='protector', charset='utf8')
    cursor = con.cursor() 
    cursor.execute(f"UPDATE account SET amount='{amounts}' WHERE username='{name}';") 
    con.commit()
    con.close()
    print(cursor.fetchone())


@app.route(f'/login')
def login():
    return render_template('login.html')


@app.route(f'/api/bank')
def banks():
    return render_template('bank.html')


@app.route(f'/api/bank_check', methods=['POST'])
def bankr():
    names = request.args.get('name')
    amounts = request.args.get('amout')

    result = bank.bank('붕어빵만들기장인', names, amounts)
    if request.method == 'POST':
        BankName = '입금 신청이 완료되었습니다 \n 몇초후 메인페이지 새로고침 후 잔액 확인 부탁드립니다. \n 입금자명'
    else:
        BankName = '입금 재시도 부탁드립니다'
    return render_template('bank_check.html', BankName=BankName)


@app.route('/api/culturland', methods=['POST'])
def cultur():
    BankName = request.args.get('BankName')
    result = culturland.charge_pin(BankName)
    if result == "0":
        return render_template('bank_check.html', BankName='충전 실패. ')
    else:
        set_amount(result, session['username'])
        return render_template('bank_check.html', BankName=f'충전 성공. {result}')
@app.route('/singup')
def singup():
    return render_template('singup.html')

@app.route('/')
def index():

    if 'username' in session:
        return render_template('main.html' , message = session['username'])
    else:
        return render_template('main.html' , message = '로그인 해주세요.')

@app.route('/shop')
def shop():
    name = get_name()
    if 'username' in session:
        return render_template('shop.html' , list=name, message = session['username'])
    else:
        return render_template('shop.html' , list=name, message = '로그인을 부탁 드립니다.')
        

@app.route('/login_check')
def login_check():
	
    username = request.args.get('username')
    password = request.args.get('password')

    login = logins(username, password)
    if login == False:
        return "아이디 또는 비밀번호가 틀립니다."
    else:
        if login == True:
            webhook.webhooks(f'{name}'.replace('(', '').replace(',', '').replace(')', '').replace("'", ''))
            session["username"] = request.args.get("username")
            return redirect(f'/')

  
    return render_template('main.html', message=username)  

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))


if __name__ == "__main__":
	app.run(host="0.0.0.0", port="80")

